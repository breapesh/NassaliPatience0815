﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBankAccountAssignment = New System.Windows.Forms.Label()
        Me.lblBalance = New System.Windows.Forms.Label()
        Me.lblamount = New System.Windows.Forms.Label()
        Me.txtbalance = New System.Windows.Forms.TextBox()
        Me.txtamount = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btndeposit = New System.Windows.Forms.Button()
        Me.btnwithdraw = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblBankAccountAssignment
        '
        Me.lblBankAccountAssignment.AutoSize = True
        Me.lblBankAccountAssignment.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBankAccountAssignment.Location = New System.Drawing.Point(133, 22)
        Me.lblBankAccountAssignment.Name = "lblBankAccountAssignment"
        Me.lblBankAccountAssignment.Size = New System.Drawing.Size(495, 37)
        Me.lblBankAccountAssignment.TabIndex = 0
        Me.lblBankAccountAssignment.Text = "BANK ACCOUNT ASSIGNMENT"
        '
        'lblBalance
        '
        Me.lblBalance.AutoSize = True
        Me.lblBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBalance.Location = New System.Drawing.Point(295, 102)
        Me.lblBalance.Name = "lblBalance"
        Me.lblBalance.Size = New System.Drawing.Size(112, 31)
        Me.lblBalance.TabIndex = 1
        Me.lblBalance.Text = "Balance"
        '
        'lblamount
        '
        Me.lblamount.AutoSize = True
        Me.lblamount.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblamount.Location = New System.Drawing.Point(295, 258)
        Me.lblamount.Name = "lblamount"
        Me.lblamount.Size = New System.Drawing.Size(107, 31)
        Me.lblamount.TabIndex = 5
        Me.lblamount.Text = "Amount"
        '
        'txtbalance
        '
        Me.txtbalance.Location = New System.Drawing.Point(307, 187)
        Me.txtbalance.Name = "txtbalance"
        Me.txtbalance.Size = New System.Drawing.Size(100, 20)
        Me.txtbalance.TabIndex = 8
        '
        'txtamount
        '
        Me.txtamount.Location = New System.Drawing.Point(301, 342)
        Me.txtamount.Name = "txtamount"
        Me.txtamount.Size = New System.Drawing.Size(100, 20)
        Me.txtamount.TabIndex = 9
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(279, 473)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(151, 23)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "s"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btndeposit
        '
        Me.btndeposit.Location = New System.Drawing.Point(78, 396)
        Me.btndeposit.Name = "btndeposit"
        Me.btndeposit.Size = New System.Drawing.Size(151, 23)
        Me.btndeposit.TabIndex = 15
        Me.btndeposit.Text = "Deposit"
        Me.btndeposit.UseVisualStyleBackColor = True
        '
        'btnwithdraw
        '
        Me.btnwithdraw.Location = New System.Drawing.Point(456, 396)
        Me.btnwithdraw.Name = "btnwithdraw"
        Me.btnwithdraw.Size = New System.Drawing.Size(151, 23)
        Me.btnwithdraw.TabIndex = 16
        Me.btnwithdraw.Text = "Withdraw"
        Me.btnwithdraw.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(812, 508)
        Me.Controls.Add(Me.btnwithdraw)
        Me.Controls.Add(Me.btndeposit)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.txtamount)
        Me.Controls.Add(Me.txtbalance)
        Me.Controls.Add(Me.lblamount)
        Me.Controls.Add(Me.lblBalance)
        Me.Controls.Add(Me.lblBankAccountAssignment)
        Me.Name = "Form1"
        Me.Text = "Bank Account"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBankAccountAssignment As Label
    Friend WithEvents lblBalance As Label
    Friend WithEvents lblamount As Label
    Friend WithEvents txtbalance As TextBox
    Friend WithEvents txtamount As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btndeposit As Button
    Friend WithEvents btnwithdraw As Button
End Class
