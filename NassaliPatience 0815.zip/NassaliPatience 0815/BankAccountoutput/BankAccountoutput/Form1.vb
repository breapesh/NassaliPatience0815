﻿Public Class Form1

    Private account As New BankAccount()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtbalance.Text = account.Balance.ToString("0.00")
        txtbalance.ReadOnly = True
    End Sub

    Private Sub btnDeposit_Click(sender As Object, e As EventArgs) Handles btndeposit.Click

        Dim amount As Decimal

        If Not Decimal.TryParse(txtAmount.Text, amount) Then
            MessageBox.Show("Please enter a valid amount.")
            Return
        End If

        Try
            account.Deposit(amount)
            txtbalance.Text = account.Balance.ToString("0.00")
            txtAmount.Clear()

            MessageBox.Show("Deposit successful.")

        Catch ex As ArgumentException
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnWithdraw_Click(sender As Object, e As EventArgs) Handles btnwithdraw.Click

        Dim amount As Decimal

        If Not Decimal.TryParse(txtAmount.Text, amount) Then
            MessageBox.Show("Please enter a valid amount.")
            Return
        End If

        Try
            account.Withdraw(amount)
            txtbalance.Text = account.Balance.ToString("0.00")
            txtAmount.Clear()

            MessageBox.Show("Withdrawal successful.")

        Catch ex As ArgumentException
            MessageBox.Show(ex.Message)

        Catch ex As InvalidOperationException
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class