﻿Public Class BankAccount

    Public Property Balance As Decimal

    Public Sub Deposit(amount As Decimal)
        If amount > 0 Then
            Balance += amount
        End If
    End Sub

    Public Function Withdraw(amount As Decimal) As Boolean
        If amount > 0 AndAlso amount <= Balance Then
            Balance -= amount
            Return True
        End If

        Return False
    End Function

End Class